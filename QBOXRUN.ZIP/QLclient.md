# Using a QDOS or SMSQ/E environment as BBS client over TCP/IP 

We'll discuss here the use of a Sinclair QL compatible system (either 
hardware-based or emulated) to connect to a BBS system over TCP/IP, 
using either the QLTERM or QTPI terminal emulators. QLTERM is included 
in the QBOX package or can be downloaded 
[here](https://github.com/janbredenbeek/QLTerm/releases). QTPI is a more 
sophisticated terminal program written for the Pointer Environment. It 
supports full ANSI/VT100 terminal emulation and ZMODEM file transfers 
and can be downloaded [here](http://www.dilwyn.me.uk/internet/qtpi.zip). 

Of course, more terminal programs have been written for the QL in the 
past 35 or so years, but these all communicate through a serial port, 
usually ser1 or ser2. It may be possible to use these as Telnet client 
on an emulated environment by using the TCP device (see below). In other 
cases, you can use a serial-to-TCP converter in which case you can use 
your QL system whilst it's totally unaware that it's connected via 
Internet rather than an old-style telephone modem. It will however have 
a severe speed impact as you will see. 

## Using QLTERM with TCP device 

If you are able to connect your QL environment to TCP/IP directly using 
QPC2, SMSQmulator or UQLX, you can communicate with QBOX (or other 
Telnet BBS systems) by OPENing a channel to the TCP device using a 
command like **OPEN_NEW#3,'tcp_192.168.1.3:5000'** and then pass this 
channel to QLTERM as parameter (e.g. using **EW QLTERM,#3**). Examples 
are in the BASIC program provided within the QLTERM package. In theory, 
QTPI should also support this method of connecting to TCP/IP systems but 
so far I haven't been able to use QTPI in this 'piped mode' (I do get a 
logon screen but no response when typing anything). 

## Using QLTERM or QTPI with the UQLX emulator 

When using the UQLX emulator, there is an extra PTY device available 
which allows you to execute unix commands and use them to pipe your 
input and output through. In QTPI, you can specify this as communication 
device instead of a serial port (click on the question mark in the left 
column, then 'Connection' and 'Comm Dev'. The device name to use is 
'pty_' followed by the unix command and parameters as you would type 
them in the unix shell. E.g. typing **pty_telnet 192.168.1.3 5000** in 
the Comm Dev field will cause QTPI to make a Telnet connection to host 
192.168.1.3 port 5000. (If the host you want to connect to supports ssh, 
use **pty_ssh <user>@<ip>** for a secure connection). Likewise, when 
using QLTERM you can specify an alternative communication device on the 
commandline, e.g. **EW QLTERM;'pty_ssh jan@192.168.1.3'**. 

## Connecting QL clients via a serial port 

If you have an original QL or Q68, you cannot connect to a TCP/IP 
network directly. One way to overcome this is to use a serial-to-TCP 
converter. This can be built using an old PC or Raspberry Pi running 
Linux and tcpser (I recommend [this](https://github.com/FozzTexx/tcpser) 
build). Most older PCs do have a serial (RS-232) port; if your PC 
doesn't or you're using a Raspberry Pi you can use a USB-to-serial 
converter (they're usually based on a PL2303 chip). After building 
tcpser from the source code, you should first determine the device name 
of your serial port. On a PC with a 'real' serial port, it will usually 
be /dev/ttyS0. If you use a USB-to-serial converter, it may be 
/dev/ttyUSB0 (when in doubt, take a look in the kernel log for messages; 
a command like **dmesg | grep 2303** might reveal it). Open a terminal 
prompt, change to the directory where tcpser resides and enter the 
command **sudo ./tcpser -d <device> -s <speed>** where <device> is the 
name of the serial port (be careful, it's case sensitive) and <speed> is 
the desired speed. 

Now you can connect the QL to your home-made serial-to-TCP converter 
using a null-modem cable. If in doubt, consult [this 
page](http://www.dilwyn.me.uk/gen/serial/serial.html) for more 
information on how to do this. On the QL, you can now start up a 
terminal program such as QLTERM, QEM or QTPI. Be sure to set it to use 
the same speed as specified on the tcpser -s command line option (use 
9600 for a start) and the correct serial port (usually ser2 when using a 
null-modem cable, ser2h or ser2hr is probably the best option). The 
tcpser program emulates a Hayes-compatible modem at the serial port, so 
if you enter 'AT' (or 'at') you should get an 'OK' reply in return. You 
can now 'dial' the BBS using the ATD command followed by the IP address 
and port number; e.g. when QBOX is running at address 192.168.1.3 and 
port 5000 the command **ATD192.168.1.3:5000** will make a connection to 
it, and if all is well it will respond with a CONNECT <speed> message 
and you'll get the login page from the BBS! 

As for the fastest possible speed, this will very much depend on your 
hardware. The original QL's ser1 and ser2 ports can receive at only up 
to 9600 bps (even though sending is supported up to 19200); for reliable 
transfers you may even have to use lower speeds. A QL equipped with the 
Hermes replacement 8049 processor should be able to receive reliably at 
19200 bps, *provided that proper flow control is being used*. The latter 
means that the DTR and CTS lines of the QL's serial port should be wired 
correctly to the CTS and RTS lines on the other end (see [this 
page](http://www.dilwyn.me.uk/gen/serial/serial.html) when in doubt). 
The reason why flow control is necessary is due to the nature of the 
QL's peripheral hardware, which will generally not be able to handle 
incoming data at full speed. This especially goes for storage media such 
as floppydisks, which tend to disable interrupts for several seconds 
while data is being written. For this reason, I recommend downloading to 
RAMdisk and copying the downloaded files to the floppydisk afterwards. 

The Q68 has a serial port which is able to send and receive at speeds up 
to 460800 bps (hardware specification) and has been tested at up to 
115200 bps. It doesn't support hardware flow control and writing data to 
the SDHC card is rather slow, so using a RAMdisk as intermediate medium 
to store downloaded files is also recommended here. The Q68's serial 
port does support software (Xon/Xoff) flow control and configurable 
send/receive buffers, but due to a bug in SMSQ/E versions 3.35 and 
earlier the configuration commands for this don't work. Wolfgang Lenerz, 
the maintainer of SMSQ/E, has been notified of this and versions later 
than 3.35 will have been fixed. 

Note that some USB-to-serial converters do not have the RTS and CTS 
lines wired and hence may cause serial overruns on the receiving QL when 
it gets more data than it can digest. To make things worse, the original 
QL's 8049 processor has a bug which renders serial input useless when 
this occurs, which lasts until the QL is hard reset! The Hermes 
replacement chip does not have this bug but you will experience garbled 
text and download errors when it cannot keep up with the serial data 
stream. There is nothing you can do short of lowering the data speed to 
avoid these problems. 

When connecting the QL to a 'real' serial port on a PC, you may also 
encounter serial overruns even when RTS and CTS are properly configured. 
This is because the 16550 UART chip, used by many serial ports, has a 
15-byte FIFO buffer in both the receive and sending channel. When the 
flow control line on the receiving end goes low to signal the sender 
that it should stop sending, it appears that the 16550 keeps sending 
data until its FIFO buffer is empty! 

## Downloading and uploading files 

If you want to download files from QBOX to the QL using a TCP-to-serial 
converter, I recommend using the latest version of QTPI (1.69) and use 
SEAlink as protocol. This is not as fast as ZMODEM, but ZMODEM is not 
supported by QBOX. When downloading files from other Telnet BBS systems, 
ZMODEM may be the preferred protocol; however it may fail when there is 
no proper flow control between the BBS and your QL. In that case, use a 
non-streaming protocol such as SEAlink, YMODEM or (not preferred!) 
XMODEM. 

